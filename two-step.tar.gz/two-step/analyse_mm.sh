#! /usr/bin/env sh
genome_fasta=$1
source_dir=$2
pre_out=$3
statistic=$4

SamToolsView_soft=$5 # full path + tool name


analyse_mm_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/two_steps/analyse_mm.pl" # if needed insert the proper path before the script name
sort_R_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/two_steps/sort_R_read.pl" # if needed insert the proper path before the script name
filter_double_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/two_steps/filter_AnalyseMM.pl"
ext_double_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/two_steps/ext_double_AnalyseMM.pl"
> $pre_out.temp_file # clear existing file or open new if not exist


for bamFILE in $source_dir/*FilterReads*.bam; do

$analyse_mm_script $genome_fasta $bamFILE $SamToolsView_soft>> $pre_out.temp_file

done


$sort_R_script $pre_out.temp_file $pre_out.temp_statistic > $pre_out.analyseMM.1
$filter_double_script --in $pre_out.analyseMM.1 --out $pre_out.analyseMM.2
$ext_double_script --in $pre_out.analyseMM.2 --out $pre_out.analyseMM
rm $pre_out.analyseMM.1
rm $pre_out.analyseMM.2
cat $pre_out.temp_statistic >> $statistic


rm $pre_out.temp_file $pre_out.temp_statistic
