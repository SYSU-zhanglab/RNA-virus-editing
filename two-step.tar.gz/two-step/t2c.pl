#!/bin/env perl -pw
use strict;

tr/Tt/Cc/ unless /^>/;
