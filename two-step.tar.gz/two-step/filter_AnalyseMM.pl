#! /usr/bin/env perl
   use strict;
   use 5.010;
   use autodie;
   use Getopt::Long;
   my($in,$out,$help);
   GetOptions("in=s"=>\$in,"out=s"=>\$out,"help"=>\$help);
   if($in and $out){
     open IN,'<',$in;
     open OUT,'>',$out;

     my $id;
     my $hit;
     my %rds;
     my $lin;
     while(<IN>){
       chomp;
       my @lines=split(/\t/,$_);
       if(m/hits:/g){
         $lin=$_;
         my @hits=split(/\:/,$lines[-1]);
         if(%rds and $id and $id ne $lines[0]){
           my @rrs=sort {$rds{$b}<=>$rds{$a}} keys %rds;
           print OUT $hit."\n".join("\n",@rrs)."\n";
           $id='';
           $hit='';
           %rds=();
        }
         $id=$lines[0];
         $hit=$_;
      }else{
         if($lines[4]>=3){
           $rds{$_}=$lines[6]/$lines[4];
        }
      }
    }
     close IN;
     my @lines=split(/\t/,$lin);
     my @hits=split(/\:/,$lines[-1]);
     my @rrs=sort {$rds{$b}<=>$rds{$a}} keys %rds;
     print OUT $hit."\n".join("\n",@rrs)."\n";
     $id='';
     $hit='';
     %rds=();
     close OUT;

   }elsif($help){
      say"This script aims to filter the AnalyseMM!\n\n
      --in:the input file;\n
      --out:the result file;\n
      --help:the help!\n";
   }else{
      print "Please read the help!\n";
   }
