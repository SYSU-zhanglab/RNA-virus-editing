#! /usr/bin/env perl
   use strict;
   use 5.010;
   use autodie;
   use Getopt::Long;
   my($in,$out,$help);
   GetOptions("in=s"=>\$in,"out=s"=>\$out,"help"=>\$help);
   if($in and $out){
     open IN,'<',$in;
     open OUT,'>',$out;

     my $id;
     my $hit;
     my %rds;
     my $lin;
     my %mix;
     while(<IN>){
       chomp;
       my @lines=split(/\t/,$_);
       if(m/hits:/g){
         $lin=$_;
         if(%rds and $id and $id ne $lines[0]){
           my @rrs=sort {$rds{$b}<=>$rds{$a}} keys %rds;
           if($#rrs==0 or ($rds{$rrs[0]}-$rds{$rrs[1]})>=0.1){
             if($mix{$rrs[0]}){
               my @lns=split(/\t/,$rrs[0]);
               if($lns[6]>=3 and ($lns[4]-$lns[6])<=2){
                 print OUT $hit."\n".$rrs[0]."\n";
              }
            }
          }
        }
         $id=$lines[0];
         %rds=();
         $hit=join("\t",@lines)."\thits:1";
      }else{
         if($lines[5]=~m/\|/){
           my @typs=split(/\|/,$lines[5]);
           $lines[5]=$typs[0];
           $rds{join("\t",@lines)}=$lines[6]/$lines[4];
           $mix{join("\t",@lines)}=1;
        }else{
           $rds{$_}=$lines[6]/$lines[4];
        }
      }
    }
     close IN;
     my @lines=split(/\t/,$lin);
     my @rrs=sort {$rds{$b}<=>$rds{$a}} keys %rds;
     if($#rrs==0 or ($rds{$rrs[0]}-$rds{$rrs[1]})>=0.1){
       if($mix{$rrs[0]}){
         my @lns=split(/\t/,$rrs[0]);
         if($lns[6]>=3 and ($lns[4]-$lns[6])<=2){
           print OUT $hit."\n".$rrs[0]."\n";
        }
      }
    }

     close OUT;

   }elsif($help){
      say"This script aims to filter the AnalyseMM!\n\n
      --in:the input file;\n
      --out:the result file;\n
      --help:the help!\n";
   }else{
      print "Please read the help!\n";
   }
