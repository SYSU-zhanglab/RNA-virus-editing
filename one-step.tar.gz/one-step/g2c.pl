#!/bin/env perl -pw
use strict;

tr/Gg/Cc/ unless /^>/;
