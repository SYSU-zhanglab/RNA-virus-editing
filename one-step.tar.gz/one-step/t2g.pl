#!/bin/env perl -pw
use strict;

tr/Tt/Gg/ unless /^>/;
