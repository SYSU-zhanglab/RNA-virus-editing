#! /usr/bin/env sh
genome_fasta=$1
source_dir=$2
pre_out=$3
statistic=$4

SamToolsView_soft=$5 # full path + tool name


analyse_mm_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/analyse_mm.pl" # if needed insert the proper path before the script name
sort_R_script="/share/public4/data/songyl/SARS-Cov2/all_res/search_GISAID/blastn/RNAseqs/new_pipeline_test/rewrite_hyper_pipeline/new_pipelines/sort_R_read.pl" # if needed insert the proper path before the script name

> $pre_out.temp_file # clear existing file or open new if not exist


for bamFILE in $source_dir/*FilterReads*.bam; do

$analyse_mm_script $genome_fasta $bamFILE $SamToolsView_soft>> $pre_out.temp_file

done


$sort_R_script $pre_out.temp_file $pre_out.temp_statistic > $pre_out.analyseMM
cat $pre_out.temp_statistic >> $statistic


#rm $pre_out.temp_file $pre_out.temp_statistic
